# Theme overrides

The same CSS works with React or the standalone theme.
See the [README](README.md) for installation, fonts, and theme initialization.

## Applying overrides

Load overrides **after** `@ala/ui/theme.css` or the standalone `phoenix.css`.
The theme defines light values on `:root` and `[data-bs-theme="light"]`, and
dark values on `[data-bs-theme="dark"]`. Override both selectors when supporting
both modes, including nested theme regions:

```css
:root, [data-bs-theme="light"] {
  --ala-color-control: #174e42;
  --ala-acknowledgement-banner-bg: #e8f4ef;
}

[data-bs-theme="dark"] {
  --ala-color-control: #b7e5d6;
  --ala-acknowledgement-banner-bg: #15362f;
}
```

These are shared custom properties: changing one can affect other components.
An override on a component itself can limit its scope, but a nested
`data-bs-theme` declaration can reset inherited values. Bootstrap properties
such as `--bs-btn-bg` are set directly on buttons, so override them on the
button or a matching selector, not only on an ancestor. Check text, control,
focus and disabled-state contrast after changing colours.

## Shared colours

Defaults below are light / dark. These semantic properties are used by the
reviewed components; they may also be used elsewhere.

| Property | Default light / dark | Use |
| --- | --- | --- |
| `--ala-color-background` | `#ffffff` / `#212121` | Button backgrounds, including disabled primary buttons |
| `--ala-color-text` | `#212121` / `#ffffff` | Button text and borders, check labels and borders, banner and arrow-link text |
| `--ala-color-link` | `#003a70` / `#c3edef` | Default result-count link text |
| `--ala-color-muted` | `#637073` / `#d9d9d9` | Disabled primary text, button icons, and link icons |
| `--ala-color-border` | `#637073` / `#9d9d9d` | Disabled primary border |
| `--ala-color-hover` | `#637073` / `#637073` | Secondary and utility button hover background; light result-count link hover text |
| `--ala-color-primary` | `#c44d34` / `#f26649` | Active link text |
| `--ala-color-divider` | `#d9d9d9` / `#4a4a4a` | Utility border fallback; filter and outline set their own borders |
| `--ala-color-control` | `#212121` / `#ffffff` | Checked checkbox and radio fill |
| `--ala-color-focus` | `#003a70` / `#ffc557` | Global and button focus-visible outline |
| `--ala-color-button-text` | `#212121` / `#ffffff` | Primary button text |
| `--ala-color-button-border` | `#c44d34` / `#f26649` | Primary button border |
| `--ala-color-button-hover` | `#f26649` / `#f26649` | Primary hover background and border |
| `--ala-color-button-hover-text` | `#212121` / `#212121` | Primary hover text |
| `--ala-color-button-active` | `#c44d34` / `#c44d34` | Primary active background and border |
| `--ala-color-button-active-text` | `#ffffff` / `#ffffff` | Primary active text |

The reviewed components also use the shared palette properties
`--ala-palette-white` (`#ffffff`), `--ala-palette-charcoal` (`#212121`),
`--ala-palette-rust` (`#c44d34`), and `--ala-palette-light-grey` (`#d9d9d9`).
Changing a palette property can affect multiple components; semantic colour
properties are generated as concrete values, not live aliases of the palette.

## Button

| Property | Default light / dark | Use |
| --- | --- | --- |
| `--ala-button-utility-active-bg` | charcoal / rust | Secondary and filter active background and border |
| `--ala-button-filter-border` | light grey / white | Filter border |
| `--ala-button-arrow` | `arrow-rust.svg` / `arrow-white.svg` | Default primary arrow image |

The colour names above refer to the palette properties in the previous section.
The outline button's active colour uses `--ala-palette-rust` instead.
Hover, active and disabled arrows use separate fixed assets or a mask, so
overriding `--ala-button-arrow` changes only the default arrow. When providing
an image URL, it resolves relative to the stylesheet containing the override.
Optional icons inherit the button colour; disabled icons use `--ala-color-muted`.

Bootstrap's button custom properties, including `--bs-btn-color`,
`--bs-btn-bg`, `--bs-btn-border-color`, their `hover`, `active` and `disabled`
equivalents, `--bs-btn-border-radius`, `--bs-btn-padding-x`,
`--bs-btn-padding-y`, `--bs-btn-font-size` and `--bs-btn-line-height`, can be
overridden on the button. The `link` variant uses Bootstrap's link-button
styles. Large button line height uses `--ala-font-line-height-button-large`
(`22px`); filter and outline font weight uses `--ala-font-weight-regular`
(`400`).

## Checkbox and radio

Unchecked controls have a transparent background and use `--ala-color-text`
for their border. Checked controls use `--ala-color-control`. Their marks are
images supplied by `--ala-check-mark` and `--ala-radio-mark`; replace these
properties with an SVG `url(...)` to change the tick or dot.

The default SVG mark colours are baked into the theme at build time: white in
light mode and charcoal in dark mode. Changing `--ala-color-control-text` at
runtime does **not** recolour them. If changing the checked fill, replace the
mark images too when necessary for contrast. Bootstrap handles indeterminate
checkboxes separately.

## Acknowledgement

| Property | Default light / dark | Use |
| --- | --- | --- |
| `--ala-acknowledgement-banner-bg` | light grey / charcoal | Banner background |
| `--ala-acknowledgement-close-opacity` | `.85` / `1` | Dismiss button opacity |

The banner text uses `--ala-color-text`. The footer uses `--ala-palette-rust`
as its background and `--ala-palette-white` for text and links. Its mobile
and desktop wave SVGs contain their own colours; changing the palette does not
recolour the artwork. Replace the footer `background-image` in CSS if needed.
Bootstrap's `--bs-alert-bg`, `--bs-alert-color`, `--bs-alert-padding-x`,
`--bs-alert-padding-y`, `--bs-alert-border-color`, and
`--bs-alert-border-radius` can also be overridden on the banner.

## Icon

Icons inherit `currentColor`, except `categories`, which uses
`--ala-color-muted`. The eight 12px arrow and chevron variants also inherit
`currentColor`; their exact Figma SVG assets are used as masks.

## Spacing and typography

The reviewed components use shared spacing properties `--ala-space-1` (`5px`),
`--ala-space-2` (`10px`), `--ala-space-3` (`15px`), `--ala-space-4` (`20px`),
`--ala-space-6` (`30px`), `--ala-space-8` (`40px`), and `--ala-space-12`
(`60px`). The acknowledgement footer also uses `--ala-font-size-body` (`16px`)
and `--ala-font-line-height-body` (`24px`). Several control dimensions and
responsive text sizes are fixed CSS values rather than custom properties.

To change the document font, override `--bs-body-font-family` after the theme.
The package does not load fonts. Generated Sass values feed Bootstrap at build
time, so changing a runtime `--ala-*` property does not retroactively change
every Bootstrap value compiled from its Sass counterpart.
