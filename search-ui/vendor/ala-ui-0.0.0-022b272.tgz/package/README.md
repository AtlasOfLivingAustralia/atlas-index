# 🐦‍🔥 phoenix 🐦‍🔥

The shared ALA design system: React-Bootstrap components, a Bootstrap Sass theme,
reviewed JSON tokens, Storybook, and Figma Code Connect. Consumers import from
`@ala/ui`; Grails applications can consume the theme without React.

**Pre-release.** The inspected [Figma inventory](design/figma-inventory.json)
contains 139 master entries: 128 candidates and 11 exclusions. **Every candidate
has an exported React component, a Storybook story and a Code Connect mapping**,
and a test enforces that coverage (see [Inventory coverage](#inventory-coverage)).
Visuals are best-effort pending designer review (see
[Design deviations](#best-effort-design-deviations)). Package publication is
intentionally disabled with `private: true` until a registry is chosen.

## Requirements and setup

- Node 26 for development and CI (`.nvmrc`; run `nvm use`). The published package still supports Node >=22.12.
- pnpm 12.18.0, as recorded in `packageManager`.
- React/React DOM 19.2 or newer within major 19, React-Bootstrap 2.10.10.
- Bootstrap 5.3.8 for rebuilding Sass; compiled CSS requires no Sass or React.

```sh
pnpm install --frozen-lockfile
pnpm exec playwright install chromium
pnpm storybook                 # Phoenix, port 6006
```

`pnpm dev` preserves the original Vite demo. `pnpm build:demo` builds it into
`dist-demo`, and `pnpm preview` serves that output. `pnpm build` now builds the
distributable library into `dist`, so the outputs cannot overwrite each other.

## Using the React library

After an approved registry/release exists:

```tsx
import { Button, initializeTheme } from "@ala/ui";
import "@ala/ui/theme.css";

// Run once before mounting React. Retain the cleanup if the host can unmount.
const stopThemeListener = initializeTheme("system");

<Button onClick={save}>Save</Button>;
<Button size="lg" arrow={false} disabled>Unavailable</Button>;
```

The CSS includes Bootstrap. **Do not also import `bootstrap.min.css` or the old
ALA combined theme**; two global Bootstrap themes are not an isolation strategy.

React, React DOM and React-Bootstrap remain peer dependencies, not bundled
copies. The React-Bootstrap public named import is deliberate: its v2
extensionless component-directory imports do not resolve in native Node ESM.
The installed-package test checks Node import safety and a real Vite build.
Importing `@ala/ui` does not access `window` or mutate the document.

### Component catalogue

Every component composes React-Bootstrap primitives (`Button`, `Form`, `Dropdown`,
`Accordion`, `Alert`, `Card`, `Navbar`, `Pagination`, …), forwards native props
and `className`, and is styled through tokens and `src/styles/`.
Stories live beside each component; open Storybook for live Controls.

Component names have no prefix. Use import aliases to distinguish them from
React-Bootstrap primitives when using both libraries.

`Tabs` renders a tab link inside React-Bootstrap `Nav`; let the group's
`activeKey` control selection.

| Level | Export | Figma masters (see inventory for node IDs) |
| --- | --- | --- |
| Atom | `Button` | Buttons/Primary, Secondary, Filter, Outline, Link (`variant`, `size`, `icon`, `iconPosition`, `arrow`) |
| Atom | `IconButton` | Chevron/arrow/map/close icon buttons (`variant`: `solid`, `outline`, `map`, `plain`) |
| Atom | `ViewButton` | Buttons/View (grid/list toggle) |
| Atom | `Icon`, `icons` | 52 icons exported from Figma as inline SVG (`currentColor`) |
| Atom | `Logo` | ALA, ALA stacked, NCRIS, CSIRO, AusTraits (light/reversed) |
| Atom | `Link` | Links (inline, standalone, arrow) |
| Atom | `Check` | Checkbox/radio |
| Atom | `Quicklink` | Quicklinks |
| Atom | `Tabs` | Tabs (section-navigation links) |
| Molecule | `Callout` | Callouts |
| Molecule | `AlertBanner` | Alert banners (info/success/warning/danger, dismissible) |
| Molecule | `Accordion` | Accordions (levels 1–2) |
| Molecule | `SearchField`, `SearchButton`, `SearchTypeSelect` | Search bar parts; `SearchField` `suggestions`/`onSuggestionSelect` render the Figma Open state as an accessible combobox; `searchTypes` holds the Figma search-type list |
| Molecule | `SortDropdown` | Sort dropdown |
| Molecule | `Pagination` | Pagination |
| Molecule | `NewsTile`, `SocialTile`, `ResultTile` | News, social and search-result tiles |
| Molecule | `Map` | Map frame and controls around a **consumer-supplied** map (no map engine bundled) |
| Molecule | `NavMenu` | Header mega-menu panel |
| Molecule | `Acknowledgement` | Acknowledgement of Country (standalone and footer) |
| Organism | `Header` | Header (large/small); `alaNavigation` holds the six Figma menu sections |
| Organism | `Footer` | Footer, including partner logos and Acknowledgement of Country |

```tsx
import { Header, Footer, Callout, Button, alaNavigation } from "@ala/ui";

<Header sections={alaNavigation} onSearch={openSearch} onSignIn={signIn} />
<Callout variant="light">
  New data is available.
  <Button variant="secondary" icon="download">Download</Button>
</Callout>
<Footer />
```

Components are presentational: consumers own routing, fetching, search, auth
and application state. Hover/pressed/focus are real browser states, not props.
Logos are packaged under `@ala/ui/assets/logos/` and referenced from the CSS,
so copy `dist/assets/` with `phoenix.css` when consuming the CSS directly.

## System, light and dark modes

`initializeTheme("system")` follows `prefers-color-scheme` and updates when the
OS preference changes. `"light"` and `"dark"` are explicit overrides and do not
subscribe to OS changes. Calling it returns a listener cleanup function. Call
cleanup before initializing the same target again.

Bootstrap's `data-bs-theme` attribute scopes both Bootstrap and `--ala-*`
variables. A locally reversed surface can use `data-bs-theme="dark"` without
changing the application's preference. Portals inherit the theme of their DOM
container, not their React parent; theme the host document or portal container.

Applications own preference storage and SSR initialization. For an SSR page,
set `data-bs-theme` before the stylesheet/first paint using the same OS/explicit
preference policy, then initialize the listener on the client. A CSP deployment
should use an approved nonce or external initializer. Do not call the browser
initializer during server rendering.

Phoenix uses Roboto (from the `font.family` token: `Roboto, Arial, sans-serif`)
but does not bundle or load it, so applications can use a different font
without downloading Roboto. Load Roboto from Google Fonts in the page `<head>`
(Storybook does this in `.storybook/preview-head.html`):

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap">
```

Without it, text falls back to Arial or the system sans-serif font. To use
another font, load it and override Bootstrap's font variable after the theme:

```css
:root { --bs-body-font-family: "Your Font", Arial, sans-serif; }
```

## Standalone theme and Grails

For Bootstrap 5.3 applications, copy the packaged `dist/phoenix.css` and
`dist/assets/` together, preserving their relative paths, and load Roboto and
the CSS in the layout (for example `grails-app/views/layouts/main.gsp`):

```html
<html lang="en" data-bs-theme="light">
  <head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap">
    <link rel="stylesheet" href="/assets/ala-ui/phoenix.css">
  </head>
</html>
```

For system-mode behavior without React, copy `dist/theme.js` too and initialize
the dependency-free module:

```html
<script type="module">
  import { initializeTheme } from "/assets/ala-ui/theme.js";
  initializeTheme("system");
</script>
```

Bundled applications can import the same function from `@ala/ui/theme`.
Server-rendered layouts should still set their initial mode before first paint.

Replace the old Bootstrap/theme stylesheet rather than layering this over it.
Keep existing application behavior/scripts intact; this package supplies no
Grails plugin or Bootstrap JavaScript replacement. A Grails application does
not need React to use the compiled theme.

Sass consumers install `bootstrap` and `sass` and can use Dart Sass's Node
package importer:

```scss
@use "pkg:@ala/ui/scss";
```

Compile with `sass --pkg-importer=node --load-path=node_modules app.scss app.css`;
a plain Sass build must also copy the
theme's assets beside its output. For custom Sass variable mappings, import the
generated token partials from a locally maintained theme integration rather
than editing generated values.

The repository's old ALA bundle identifies Bootstrap 5.3.3; that is evidence
about the fixture, not every deployed Grails application. Bootstrap 3/4, Less,
old browser targets and downstream application upgrades are **unverified and
not supported by this build**. They require explicit adapters/migration work.

## Design tokens

Sources:

- `tokens/primitives.json`: named palette, spacing, typography and radius
  values inspected in Figma.
- `tokens/light.json` and `tokens/dark.json`: semantic mappings. Beyond the
  Bootstrap roles (`primary`, `text`, `surface`, `link`, `danger`, …) and
  button states, components use `divider`, `chrome` (header/footer
  background), `hover`, `control`/`controlText` (dark pill controls) and
  `surfaceAlt` (tiles/callouts), `acknowledgementBackground`,
  `accordionBackground`/`accordionHeading`/`accordionBorder`,
  `navigationIcon` and `utilityActive`. `visibility.artworkLight` and
  `visibility.artworkDark` are Boolean mode tokens that select the approved
  logo artwork in Figma without recolouring brand assets.
- `scripts/build-tokens.mjs`: validation and Style Dictionary transforms.

The `$type`/`$value` JSON is normalized for Style Dictionary; it is not claimed
as a verbatim native Figma export or a complete finalized DTCG interchange file.
Mode semantics and Bootstrap role assignments are best-effort engineering
choices, not designer-approved variable bindings.

```sh
pnpm tokens:build
pnpm build
```

Generation produces deterministic Sass variables and mode-scoped CSS custom
properties under `src/styles/generated/` (ignored, never hand-edited). Sass
variables feed Bootstrap before compilation; runtime properties drive the
Phoenix states. Invalid types, units, references, cycles, mode-name mismatches
and generated-name collisions fail the build.

See [THEME.md](THEME.md) for component-specific runtime overrides and notes.

The package exports primitive JSON via `@ala/ui/tokens`, mode JSON via
`@ala/ui/tokens/light` and `@ala/ui/tokens/dark`, and compiled CSS via
`@ala/ui/theme.css`. For example:

```css
.custom-surface {
  color: var(--ala-color-text);
  background: var(--ala-color-surface);
  padding: var(--ala-space-4);
}
```

**Change workflow:** export/review Figma values, normalize the JSON while
preserving aliases/modes, review semantic assignments, regenerate, run tests,
and compare the affected stories. Builds do not contact Figma. A full export
plugin/process and complete typography/grid/component token coverage remain
to be finalized; do not infer missing design values from Bootstrap defaults.

**Tokens Studio sync:** Tokens Studio pushes `tokens/*.json` to the
`tokens-sync` branch. The `Tokens sync` workflow opens or updates a PR into
`testing`, comments a token change summary
(`node scripts/summarize-token-changes.mjs <base-ref>`), and merges the PR once
`Library checks` passes for the pushed commit. If token files are also edited
directly on `testing`, the merge can hit conflicts and fail. Those need
resolving by hand.

## Figma, inventory and component contributions

[ALA Design System](https://www.figma.com/design/QMo2639puZHfa7mnWOduZI/ALA-Design-System):
foundations `1:2707`, masters `96:6530`, atoms `104:693`, molecules
`104:849`/`118:2843`, organisms `104:1373`/`118:3346`.

Components inherit the **Appearance** Light/Dark variable mode; the legacy
`Colour=Reversed` variants have been removed. Set the mode on a containing
frame in Figma, or use Storybook's colour-mode toolbar. Code Connect does not
pin component themes. Alert and Light callouts remain separate component
types; approved alternate logo artwork switches automatically. The ALA
stacked logo retains its single approved asset in both modes; use it on a
light surface until approved dark artwork is supplied.

After pulling these tokens into Tokens Studio, keep Primitives as the source
set for both Appearance themes and export **Variables**, including the two
Boolean visibility tokens. Do not flatten aliases or recreate Reversed variants.
Before publishing the Figma library update, check consumers in other Figma
files: their instances of deleted variants may need replacing.

The JSON inventory records master IDs and observed variants. Per the requested
best-effort policy, hidden masters, temporary layouts and anonymous duplicate
`Icons` entries are excluded pending review. Remaining visible masters are
candidates, not certified published/approved components. Full product pages,
live search/auth/social integrations and a bundled map engine are out of scope.

For each candidate:

1. Inspect its actual master, screenshot, properties, variants and assets.
2. Reuse themed React-Bootstrap or existing Phoenix components; add only the
   composition and design-specific differences.
3. Keep the public API typed; preserve validation, native semantics, refs and
   keyboard behavior. Consumers own navigation, fetching and application state.
4. Co-locate `.stories.tsx`, styles, focused behavior tests and `.figma.ts`
   templates under `src/atoms`, `src/molecules` or `src/organisms`.
5. Add the supported API to `src/index.ts` and the declaration build, and record
   implementation/story/mapping coverage in the inventory.
6. Test mobile/desktop, inherited modes, explicit theme overrides,
   focus/hover/pressed/disabled and applicable empty/error states.
   Document best-effort design deviations.

Figma property names are taken from the masters themselves (for example
`Size`, `State`, `Icon`), never from illustrative snippets.

### Inventory coverage

Each candidate in `design/figma-inventory.json` records
`implementation: { export, story, codeConnect }`; exclusions record `null`.
`src/inventory.test.ts` (part of `pnpm test`) fails if any candidate lacks an
export from `src/index.ts`, an existing story file, or **exactly one** Code
Connect entry whose URL, component and source match the inventory. It also
executes the template for every entry (default plus each mapped enum option),
checks the generated TSX parses, and checks that mapped Figma options exist in
the recorded variants. When adding or renaming a Figma master, update the
inventory first and let the test tell you what is missing.

### Best-effort design deviations

These were guessed or approximated and need designer review:

- Navigation hrefs in `alaNavigation` and nav-menu descriptions are placeholders.
- Secondary button `Icon` Left/Right maps to arrow-left/arrow-right icons.
- Footer Acknowledgement of Country waves are gradient bands, not the artwork.
- Level-1 accordion headings use rust (light) and the text colour (dark),
  because flamingo on the dark surface fails WCAG AA contrast (3.66:1).
- Search placeholder uses the muted colour; icon-button labels ("Next",
  "Previous", "Search", …) are inferred accessible names.
- Result tiles render `details` as a list; the social tile has no live feed.
- Desktop result rows grow past Figma's fixed 87px when a long title wraps,
  rather than clipping it; detail lines and descriptions truncate as in Figma.
- Tabs State=Hover is 55px tall in Figma (20px bottom padding) while Default
  and Selected are 52px; hover keeps 52px so the row doesn't shift.
- Selected Tabs labels on the grey search hero (Figma ALA Search final frames)
  are 4.21:1 (light) and 3.67:1 (dark), below WCAG AA; kept as designed pending
  designer review. The 3px underline meets the 3:1 non-text requirement.
- Hover/click Figma variants are browser states, so they are mostly unmapped in
  Code Connect (`Tabs`' `Selected` state maps to `active` and `aria-current`).
- Pagination marks the current page with bold, underlined text, a contrasting
  border and `aria-current="page"`. **Update the Figma pagination masters** to
  include this selected-page indicator in both themes.

Design owners should review tokens/visual changes; maintainers own API/release
compatibility; application teams own integration. Target WCAG 2.2 AA, but do not
treat automated checks as accessibility certification or this inventory as
designer sign-off.

## Code Connect

Mappings use Figma's maintained template API (not the deprecated
`@figma/code-connect/react` parser). Because 128 masters share the same shape,
they use the CLI's **batch** form:

- `src/figma/ala.figma.batch.ts` is one shared, typed template.
- Each component has a co-located `*.figma.batch.json` (25 files) listing its
  Figma masters:

```json
{
  "templateFile": "../figma/ala.figma.batch.ts",
  "components": [{
    "id": "ala-99-7098",
    "url": "https://www.figma.com/design/QMo2639puZHfa7mnWOduZI/ALA-Design-System?node-id=99-7098",
    "component": "Button",
    "source": "src/atoms/Button.tsx",
    "props": { "onClick": { "expr": "handleClick" } },
    "enums": {
      "Size": { "prop": "size", "values": { "Small": "sm", "Large": "lg" } },
      "Colour": { "prop": "data-bs-theme", "values": { "Reversed": "dark" } }
    },
    "text": [{ "layer": "Primary button" }]
  }]
}
```

Entry fields: `enums` map a Figma variant property to a React prop (or to a
prop object such as `data-bs-theme`); `text` reads a text layer into `children`
(no `prop`), a named prop, or an array prop (`list`); `{ "expr": "…" }` emits a
raw JSX expression; `imports` adds extra named imports from `@ala/ui`. Dev Mode
snippets therefore show `import { Button } from "@ala/ui";` and real props.
Templates and JSON are excluded from the runtime bundle; `figma.config.json`
includes `src/**/*.figma.batch.json`.

```sh
pnpm figma:typecheck            # type-check the template
pnpm figma:parse                # offline: renders all 128 docs
pnpm figma:preview
```

Preview, network validation and publishing need `FIGMA_ACCESS_TOKEN` from your
local shell's secret mechanism or the approved CI secret store. **Never paste
it into chat, commit it, put it in browser code, or pass it as a command
argument.** The token needs File content Read; publishing also needs Code
Connect Write and a Dev or Full seat on an eligible plan.

```sh
FIGMA_ACCESS_TOKEN=… pnpm figma:check    # dry-run publish against Figma
FIGMA_ACCESS_TOKEN=… pnpm figma:publish  # explicit publication, after review
```

Publishing adds Code Connect metadata to the shared Figma file, linking each
Figma component to its `@ala/ui` source and generated code example. Connected
components then show those snippets in Dev Mode. It does **not** edit the
design: it leaves layers, components, variants, styles and variables unchanged.
Anyone with Dev Mode access to the file can see the published snippets.

`figma:check` is a dry run and does not publish. CI republishes the mappings
automatically after every push to `main` that passes all checks (the
`figma-publish` job), using the `FIGMA_ACCESS_TOKEN` repository secret
(Settings → Secrets and variables → Actions). If the secret is missing, that
job fails and nothing is published. Review the snippets in Dev Mode, including
reversed and size variants, after mapping changes.

## Storybook and designer review

Phoenix Storybook uses the production Sass/token theme and system/light/dark
toolbar. Use the colour mode selector to compare themes on both Canvas and Docs
pages, and the viewport selector to compare responsive layouts. Stories follow
those controls instead of duplicating light/dark pages; nested theme-override
demos use explicitly scoped surfaces. Canvas themes cover the entire page,
including its padding. Docs examples scope their theme, text colour and
background to each padded story area, so examples cannot change one another's
theme.

Leave the **Preview background** selector unset to follow the colour mode. Its
**ALA light** and **ALA dark** options override the surface independently, for
checking components against the other theme's background.

The dismissible alert example includes **Reset banner** to restore it after
closing. Dropdown examples reserve room for their expanded menus. Offline
placeholder artwork lives in `src/stories/assets/` and is shared through
`src/stories/fixtures.ts`, not embedded as SVG strings in story args.
Accessibility violations fail Phoenix browser tests.

```sh
pnpm build-storybook
```

`.storybook/manager-head.html` shows a pre-release banner on every page; remove
it when the library is released.

### Storybook hosting on AWS

The Phoenix Storybook is hosted on AWS using the same CodePipeline and
CloudFormation pattern as the
[AVSB `cicd/`](https://github.com/AtlasOfLivingAustralia/avsb/tree/testing/cicd).
CodePipeline, not GitHub Actions, watches the branch and deploys it:

| Branch | Environment | URL |
| --- | --- | --- |
| Feature branches | development, one per branch | `https://phoenix-<branch>.dev.ala.org.au` |
| `testing` | testing | <https://phoenix.test.ala.org.au> |
| `main` | staging | <https://phoenix-staging.ala.org.au> |
| `main` | production (manual release) | <https://phoenix.ala.org.au> |

Each pipeline checks out the branch and exports `cicd/storybook/config.ini`
settings. It deploys a WAF stack (us-east-1) and an S3, CloudFront and Route 53
stack, then runs the same checks as the GitHub CI library job (build, type
check, lint, unit, Figma, Storybook interaction/accessibility and package
tests) before `pnpm build-storybook`. Any failure stops the pipeline before the
bucket is touched. Otherwise, it replaces the bucket contents with
`storybook-static/` and sends deploy notifications. Keep
`cicd/storybook/pipeline/npm_build_buildspec.yaml` in sync with
`.github/workflows/ci.yml`.
Every push to the tracked branch deploys, except production, where
`AUTO_DEPLOY = false`; use **Release change** in CodePipeline instead. If
`pipeline.yaml` changes, the pipeline updates itself and restarts.

- `config.ini` (repository root): shared ALA settings, including the product
  name, repository, region, Bedrock bootstrap stacks and certificates.
- `cicd/storybook/config.ini`: Storybook settings, including buckets,
  subdomains, cache ages and the IP allowlist.
- `cicd/storybook/app/`: CloudFormation for the site and WAF, plus parameter
  templates.
- `cicd/storybook/pipeline/`: the CodePipeline template, CodeBuild buildspecs
  and `deploy_pipeline.sh`.
- `cicd/*.py`, `cicd/*.sh`: shared helpers copied from AVSB. Keep them in sync
  with it.

**Access:** pre-release, every environment is limited by WAF to the ALA/CSIRO
networks in `ALLOW_LISTED_IPS`. Other visitors get `403`. To make an environment
public, add `ALLOW_LISTED_IPS = 0.0.0.0/1, 128.0.0.0/1` to its section in
`cicd/storybook/config.ini` (AVSB's public setting) and push.

**Bootstrapping:** each environment's pipeline is created once. Development
needs one pipeline per branch. Log in with the AWS CLI to the account for that
environment (development and testing use a different account from staging and
production; see the certificate ARNs in `config.ini`). Commit and push the
branch, then run:

```sh
cd cicd/storybook/pipeline
./deploy_pipeline.sh            # on main, prompts for staging or production
```

The pipeline reads source through the shared ALA CodeConnections connection
(from the Bedrock bootstrap stack), backed by the **AWS Connector for GitHub**
app. Because this repository is private, that app must be granted access to it,
or the `Checkout_Source` stage fails. A GitHub org owner opens
**Organization settings → GitHub Apps → AWS Connector for GitHub → Configure →
Repository access**, adds `phoenix` (or uses "All repositories") and saves.
Then use **Release change** on the failed pipeline. Confirm the connection is
**Available** under **Developer Tools → Settings → Connections** in each AWS
account (dev/test and staging/production use different accounts).

Deploy branches are protected and changed only through pull requests: feature
→ `testing` → `main`. Remove a development environment with the pipeline's
**Teardown** stage. Roll back with **Release change** and a previous commit.

[Storybook Connect](https://www.chromatic.com/docs/figma-plugin/) is separate
from Code Connect. It requires a Chromatic-hosted Storybook, Figma edit access
and a Chromatic collaborator account. After service approval, designers install
the plugin, authenticate, select a master/variant and paste its stable
Chromatic branch story URL. Verify another collaborator can open it and that
the link updates after a new build.

Chromatic is not selected or configured, so there is no visual-difference
review. The installed addon is not proof that stories are embedded in Figma.
The hosted Storybook and ordinary Storybook/Figma links remain usable, but the plugin
workflow is not complete. There is no automatic bidirectional code/design
synchronization.

## Package scripts

Run these commands from the repository root after completing
[setup](#requirements-and-setup). They are the scripts defined in `package.json`.

### Development and builds

| Command | What it does |
| --- | --- |
| `pnpm dev` | Starts the original Vite demo development server. |
| `pnpm build:demo` | Type-checks the project and builds the demo into `dist-demo/`. |
| `pnpm preview` | Serves the built demo locally; run `pnpm build:demo` first. |
| `pnpm tokens:build` | Validates the JSON tokens and generates Sass and CSS properties in `src/styles/generated/`. |
| `pnpm build` | Regenerates tokens and builds the distributable library, declarations, theme and assets into `dist/`. It does not publish a package. |
| `pnpm storybook` | Regenerates tokens and starts Phoenix Storybook on port 6006. |
| `pnpm build-storybook` | Regenerates tokens and builds Phoenix Storybook into `storybook-static/`. |

### Tests and lint

| Command | What it does |
| --- | --- |
| `pnpm test` | Regenerates tokens and runs the Node-based Vitest suite, including token, theme and inventory tests. |
| `pnpm test:stories` | Regenerates tokens and runs Storybook interaction and accessibility tests in Playwright Chromium with light and dark system preferences. |
| `pnpm test:storybook-theme` | Checks Canvas page backgrounds, Docs theme isolation, toolbar/system changes, ALA preview backgrounds and the absence of duplicate theme stories in Chromium. Run `pnpm build-storybook` first. |
| `pnpm test:package` | Packs and installs the library in a temporary consumer, then checks types, builds, imports, theme and assets in Chromium. |
| `pnpm lint:library` | Runs ESLint on the Phoenix library, tests and tooling. |
| `pnpm lint` | Runs ESLint across the whole repository. |

### Figma Code Connect

| Command | What it does |
| --- | --- |
| `pnpm figma:typecheck` | Type-checks the shared Code Connect template. |
| `pnpm figma:parse` | Parses the local mappings offline and reports unreadable files. |
| `pnpm figma:preview` | Fetches Figma data and previews the generated snippets without publishing. |
| `pnpm figma:check` | Runs a Figma publication dry run without changing published connections. |
| `pnpm figma:publish` | Publishes the mappings to Figma; it does not change the design. |

### Packaging

| Command | What it does |
| --- | --- |
| `pnpm prepack` | Runs `pnpm build`; pnpm also invokes this lifecycle script automatically before `pnpm pack`, including during `pnpm test:package`. |

`figma:preview`, `figma:check` and `figma:publish` require a Figma access token;
see [Code Connect](#code-connect). The browser tests require Playwright
Chromium as described in [setup](#requirements-and-setup).

## Checks and release workflow

`test:package` needs registry access for a temporary consumer installation. It
tests the actual tarball, not a source alias, including CSS types, Node-safe
imports, external peers, mode changes, standalone Bootstrap markup and loaded
arrow assets. Temporary installations/servers/browsers are cleaned up.

CI runs the library checks and Storybook build on pull requests and on pushes to
`main`, `testing`, and `tokens-sync`.
Only pushes to `main` that pass them publish Code Connect; pull requests never
receive the Figma secret. Storybook is deployed by AWS CodePipeline (see
[Storybook hosting on AWS](#storybook-hosting-on-aws)), not GitHub Actions, so
its deploys don't wait for these checks. `pnpm lint` runs the full-repository
lint locally.

Before publishing: resolve the documented design deviations with designers, validate actual Grails targets, run manual
visual/keyboard/screen-reader reviews, choose a registry and Chromatic, review
the tarball/license/asset rights, and remove `private: true` only as an approved
release change. Use protected release workflows, semver and release notes;
pin a prior package/theme version to roll back. Token/API changes require
compatibility review, not merely a successful build.

The root project license is GPL-3.0; imported legacy files retain their existing
MPL notices. Confirm redistribution permissions for Figma brand artwork and any
fonts before external publication. CI publishes Code Connect from `main`, and
AWS CodePipeline deploys Storybook once each environment is bootstrapped; no
package registry or Chromatic project is created automatically.